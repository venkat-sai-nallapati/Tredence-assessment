package com.civalue.personalized_data.service;



@Log4j2
@Service
public class ProductAndShopperService {

  @Autowired
  ProductDao productDao;

  @Autowired
  ShopperDao shopperDao;

  @Transactional(rollbackOn = Exception.class)
  public String insertProductAndShopperData(
      PersonalizedAndProductRequestDto personalizedAndProductRequestDto) throws Exception {
    try {
      List<ProductEntityDto> productEntityList = new ArrayList<>();
      personalizedAndProductRequestDto.getProductMetaDataListRequestDto().forEach(each -> {
        ProductEntityDto productEntityDto = new ProductEntityDto();
        BeanUtils.copyProperties(each, productEntityDto);
        productEntityList.add(productEntityDto);
      });
      productEntityList.forEach(e -> log.info(e));
      int productInsertedCount = productDao.insertProducts(productEntityList);
      List<ShopperEntityDto> shopperEntityList = new ArrayList<>();
      personalizedAndProductRequestDto.getPersonalizedInfoListRequestDto().forEach(each -> {
        Map<String, String> tempMap = new HashMap<>();
        each.getShelf().forEach(eachShelf -> {
          if (!tempMap.containsKey(eachShelf.getProductid())) {
            tempMap.put(eachShelf.getProductid(), eachShelf.getProductid());
            ShopperEntityDto shopperEntityDto = new ShopperEntityDto();
            shopperEntityDto.setShopperid(each.getShopperid());
            shopperEntityDto.setProductid(eachShelf.getProductid());
            shopperEntityDto.setRelevancyscore(eachShelf.getRelevancyscore());
            shopperEntityList.add(shopperEntityDto);
          }

        });

      });
      shopperEntityList.forEach(e -> log.info(e));
      int shopperInsertedCount = shopperDao.insertShoppers(shopperEntityList);
      return "productsInserted : " + productInsertedCount + " , shoppersInserted "
          + shopperInsertedCount;
    } catch (Exception e) {
      log.info("-----------Exception handled-------------");
      throw e;
      // return "One or more product id's does not exists in product table";
    }
  }
}
