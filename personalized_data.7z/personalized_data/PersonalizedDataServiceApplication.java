package com.civalue.personalized_data;



@SpringBootApplication
@Log4j2
public class PersonalizedDataServiceApplication {

  public static void main(String[] args) {
    SpringApplication.run(PersonalizedDataServiceApplication.class, args);
    log.info("end");
  }

}
