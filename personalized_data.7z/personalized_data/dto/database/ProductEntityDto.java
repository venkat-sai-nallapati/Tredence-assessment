package com.civalue.personalized_data.dto.database;



@Entity
@Table(name = "product")
public class ProductEntityDto {

  @Id
  private String productid;

  private String category;

  private String brand;

  public String getProductid() {
    return productid;
  }

  public void setProductid(String productid) {
    this.productid = productid;
  }

  public String getCategory() {
    return category;
  }

  public void setCategory(String category) {
    this.category = category;
  }

  public String getBrand() {
    return brand;
  }

  public void setBrand(String brand) {
    this.brand = brand;
  }

  @Override
  public String toString() {
    return "ProductEntityDto [productid=" + productid + ", category=" + category + ", brand="
        + brand + "]";
  }


}
