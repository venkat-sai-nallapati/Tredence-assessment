package com.civalue.personalized_data.dto.request;



public class PersonalizedAndProductRequestDto {

  private List<PersonalizedInfoRequestDto> personalizedInfoListRequestDto;

  private List<ProductMetaDataRequestDto> productMetaDataListRequestDto;



  public List<PersonalizedInfoRequestDto> getPersonalizedInfoListRequestDto() {
    return personalizedInfoListRequestDto;
  }



  public void setPersonalizedInfoListRequestDto(
      List<PersonalizedInfoRequestDto> personalizedInfoListRequestDto) {
    this.personalizedInfoListRequestDto = personalizedInfoListRequestDto;
  }



  public List<ProductMetaDataRequestDto> getProductMetaDataListRequestDto() {
    return productMetaDataListRequestDto;
  }



  public void setProductMetaDataListRequestDto(
      List<ProductMetaDataRequestDto> productMetaDataListRequestDto) {
    this.productMetaDataListRequestDto = productMetaDataListRequestDto;
  }



  @Override
  public String toString() {
    return "PersonalizedAndProductRequestDto [personalizedInfoListRequestDto="
        + personalizedInfoListRequestDto + ", productMetaDataListRequestDto="
        + productMetaDataListRequestDto + "]";
  }


}
