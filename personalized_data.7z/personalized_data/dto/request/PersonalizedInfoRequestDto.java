package com.civalue.personalized_data.dto.request;


public class PersonalizedInfoRequestDto {

  @JsonProperty("shopperId")
  private String shopperid;

  private List<ShelfItem> shelf;

  public String getShopperid() {
    return shopperid;
  }

  public void setShopperid(String shopperid) {
    this.shopperid = shopperid;
  }

  public List<ShelfItem> getShelf() {
    return shelf;
  }

  public void setShelf(List<ShelfItem> shelf) {
    this.shelf = shelf;
  }

  @Override
  public String toString() {
    return "PersonalizedInfoRequestDto [shopperid=" + shopperid + ", shelf=" + shelf + "]";
  }


}
