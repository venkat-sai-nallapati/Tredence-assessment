package com.civalue.personalized_data.mapper;


@Repository
public interface ProductRepository extends JpaRepository<ProductEntityDto, String> {

  @Query("SELECT s.shopperid FROM ShopperEntityDto s WHERE s.productid = :productid")
  List<String> findShoppersByProductid(@Param("productid") String productid, Pageable pageable);
}
