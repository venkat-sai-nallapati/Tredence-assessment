package com.civalue.personalized_data.repository;



@Log4j2
@Repository
public class ProductDao {

  @Autowired
  ProductRepository productRepository;

  public int insertProducts(List<ProductEntityDto> productEntityDto) {
    List<ProductEntityDto> insertedList = productRepository.saveAll(productEntityDto);
    log.info("..........End of product insertion...............");
    return insertedList.size();
  }

  public List<String> getShoppersByProductid(String productid, Integer limit) {
    int defaultLimit = 10;
    int maxLimit = 1000;
    int finalLimit = 0;
    if (limit != null) {
      finalLimit = limit==0?defaultLimit:Math.min(limit, maxLimit);
    } else {
      finalLimit = defaultLimit;
    }

    Pageable pageable = PageRequest.of(0, finalLimit);
    return productRepository.findShoppersByProductid(productid, pageable);
  }
}
