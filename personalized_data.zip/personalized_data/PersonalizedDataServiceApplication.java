package com.civalue.personalized_data;



@SpringBootApplication
public class PersonalizedDataServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PersonalizedDataServiceApplication.class, args);
		System.out.println("end");
	}

}
