package com.civalue.personalized_data.dto.database;



public class ShopperPK implements Serializable{

  private String shopperid;

  private String productid;

  public String getShopperid() {
    return shopperid;
  }

  public void setShopperid(String shopperid) {
    this.shopperid = shopperid;
  }

  public String getProductid() {
    return productid;
  }

  public void setProductid(String productid) {
    this.productid = productid;
  }

  @Override
  public String toString() {
    return "ShopperPK [shopperid=" + shopperid + ", productid=" + productid + "]";
  }

  @Override
  public int hashCode() {
    return Objects.hash(productid, shopperid);
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (!(obj instanceof ShopperPK))
      return false;
    ShopperPK other = (ShopperPK) obj;
    return Objects.equals(productid, other.productid) && Objects.equals(shopperid, other.shopperid);
  }


}
