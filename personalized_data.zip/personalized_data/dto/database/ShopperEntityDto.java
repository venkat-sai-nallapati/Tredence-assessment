package com.civalue.personalized_data.dto.database;



@IdClass(ShopperPK.class)
@Entity
@Table(name = "shopper")
public class ShopperEntityDto implements Serializable{

  @Id
  private String shopperid;

  // @ManyToOne
  // @JoinColumn(name = "productid")
  @Id
  private String productid;

  private Double relevancyscore;

  public String getShopperid() {
    return shopperid;
  }

  public void setShopperid(String shopperid) {
    this.shopperid = shopperid;
  }

  public String getProductid() {
    return productid;
  }

  public void setProductid(String productid) {
    this.productid = productid;
  }

  public Double getRelevancyscore() {
    return relevancyscore;
  }

  public void setRelevancyscore(Double relevancyscore) {
    this.relevancyscore = relevancyscore;
  }

  @Override
  public String toString() {
    return "ShopperEntityDto [shopperid=" + shopperid + ", productid=" + productid
        + ", relevancyscore=" + relevancyscore + "]";
  }


}
