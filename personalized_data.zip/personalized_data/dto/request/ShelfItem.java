package com.civalue.personalized_data.dto.request;


public class ShelfItem {

  @JsonProperty("productId")
  private String productid;

  @JsonProperty("relevancyScore")
  private Double relevancyscore;

  public String getProductid() {
    return productid;
  }

  public void setProductid(String productid) {
    this.productid = productid;
  }

  public Double getRelevancyscore() {
    return relevancyscore;
  }

  public void setRelevancyscore(Double relevancyscore) {
    this.relevancyscore = relevancyscore;
  }

  @Override
  public String toString() {
    return "ShelfItem [productid=" + productid + ", relevancyscore=" + relevancyscore + "]";
  }


}
