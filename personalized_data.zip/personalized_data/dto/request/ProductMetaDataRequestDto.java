package com.civalue.personalized_data.dto.request;


public class ProductMetaDataRequestDto {

  @JsonProperty("productId")
  private String productid;

  private String category;

  private String brand;

  public String getProductid() {
    return productid;
  }

  public void setProductid(String productid) {
    this.productid = productid;
  }

  public String getCategory() {
    return category;
  }

  public void setCategory(String category) {
    this.category = category;
  }

  public String getBrand() {
    return brand;
  }

  public void setBrand(String brand) {
    this.brand = brand;
  }

  @Override
  public String toString() {
    return "ProductMetaDataRequestDto [productid=" + productid + ", category=" + category
        + ", brand=" + brand + "]";
  }

}
