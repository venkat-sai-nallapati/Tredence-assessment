package com.civalue.personalized_data.dto.response;

public class ShopperResponseDto {

}
