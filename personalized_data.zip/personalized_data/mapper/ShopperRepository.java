package com.civalue.personalized_data.mapper;



@Repository
public interface ShopperRepository extends JpaRepository<ShopperEntityDto, String> {

  @Query("SELECT new com.civalue.personalized_data.dto.database.ProductDto(s.productid, p.category, p.brand) "
      + "FROM ShopperEntityDto s INNER JOIN ProductEntityDto p ON s.productid = p.productid WHERE s.shopperid = :shopperid"
      + " AND (:category IS NULL OR p.category = :category) AND (:brand IS NULL OR p.brand = :brand)")
  List<ProductDto> findProductsByShopperid(@Param("shopperid") String shopperid, String category,
      String brand, Pageable pageable);
}
