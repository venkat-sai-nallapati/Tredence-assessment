package com.civalue.personalized_data.controller;


@RestController
public class PersonalizedController {

  @Autowired
  ProductAndShopperService productAndShopperService;

  @Autowired
  ShopperDao shopperDao;

  @Autowired
  ProductDao productDao;

  @PostMapping("/products")
  public ResponseEntity<String> createProduct(
      @RequestBody PersonalizedAndProductRequestDto personalizedAndProductRequestDto) {
    System.out.println("personalizedAndProductRequestDto" + personalizedAndProductRequestDto);
    String postResponse;
    try {
      postResponse =
          productAndShopperService.insertProductAndShopperData(personalizedAndProductRequestDto);
    } catch (Exception e) {
      postResponse = "ProductId not exists in product table";
      return ResponseEntity.badRequest().body(postResponse);
    }
    return ResponseEntity.ok(postResponse);
  }

  @GetMapping("/getProductsByShopperDetails/{shopperid}")
  public ResponseEntity<List<ProductResponseDto>> getProductsByShopperId(
      @PathVariable("shopperid") String shopperid,
      @RequestParam(name = "limit", required = false) Integer limit,
      @RequestParam(name = "category", required = false) String category,
      @RequestParam(name = "brand", required = false) String brand) {
    System.out.println(shopperid);
    System.out.println("limit is " + limit);
    System.out.println("category is " + category);
    System.out.println("brand is " + brand);
    List<ProductDto> productList =
        shopperDao.getProductsByShopperid(shopperid, limit, category, brand);
    List<ProductResponseDto> productResponseList = new ArrayList<>();
    if (productList.isEmpty()) {
      return ResponseEntity.badRequest().body(productResponseList);
    }
    productList.forEach(each -> {
      ProductResponseDto productResponseDto = new ProductResponseDto();
      BeanUtils.copyProperties(each, productResponseDto);
      productResponseList.add(productResponseDto);
    });
    return ResponseEntity.ok(productResponseList);

  }

  @GetMapping("/getShoppersByProductDetails/{productid}")
  public ResponseEntity<List<String>> getShoppersByProductId(
      @PathVariable("productid") String productid,
      @RequestParam(name = "limit", required = false) Integer limit) {
    System.out.println(productid);
    System.out.println("limit is" + limit);
    List<String> shopperList = productDao.getShoppersByProductid(productid, limit);
    if (shopperList.isEmpty()) {
      return ResponseEntity.badRequest().body(shopperList);
    }
    return ResponseEntity.ok(shopperList);

  }
}
