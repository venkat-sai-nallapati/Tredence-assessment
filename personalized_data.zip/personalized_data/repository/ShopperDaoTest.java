package com.civalue.personalized_data.repository;



@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = {PersonalizedDataServiceApplication.class})
@AutoConfigureMockMvc
public class ShopperDaoTest {

  @Mock
  private ShopperRepository shopperRepository;

  @InjectMocks
  private ShopperDao shopperDao;

  @Test
  public void test_insertShoppers_normal() {
    List<ShopperEntityDto> shoppers = new ArrayList<>();
    when(shopperRepository.saveAll(shoppers)).thenReturn(shoppers);
    int result = shopperDao.insertShoppers(shoppers);
    assertEquals(shoppers.size(), result);
    verify(shopperRepository, times(1)).saveAll(shoppers);
  }

  @Test
  public void test_getProductsByShopperid_normal() {
    String shopperId = "123";
    int limit = 10;
    String category = "someCategory";
    String brand = "someBrand";
    List<ProductDto> products = new ArrayList<>();
    Pageable pageable = PageRequest.of(0, limit);
    when(shopperRepository.findProductsByShopperid(shopperId, category, brand, pageable))
        .thenReturn(products);
    List<ProductDto> result = shopperDao.getProductsByShopperid(shopperId, limit, category, brand);
    assertEquals(products, result);
    verify(shopperRepository, times(1)).findProductsByShopperid(shopperId, category, brand,
        pageable);
  }

  @Test
  public void test_getProductsByShopperid_nullLimit() {
    String shopperId = "123";
    int limit = 10;
    String category = "someCategory";
    String brand = "someBrand";
    List<ProductDto> products = new ArrayList<>();
    Pageable pageable = PageRequest.of(0, limit);
    when(shopperRepository.findProductsByShopperid(shopperId, category, brand, pageable))
        .thenReturn(products);
    List<ProductDto> result = shopperDao.getProductsByShopperid(shopperId, null, category, brand);
    assertEquals(products, result);
    verify(shopperRepository, times(1)).findProductsByShopperid(shopperId, category, brand,
        pageable);
  }
}
