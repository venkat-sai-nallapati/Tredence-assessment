package com.civalue.personalized_data.repository;


@Repository
public class ShopperDao {

  @Autowired
  ShopperRepository shopperRepository;

  public int insertShoppers(List<ShopperEntityDto> shopperEntityDto) {
    System.out.println("shopper entity count " + shopperEntityDto.size());
    List<ShopperEntityDto> insertedList = shopperRepository.saveAll(shopperEntityDto);
    System.out.println("..........End of shopper insertion..............." + insertedList.size());
    return insertedList.size();
  }


  public List<ProductDto> getProductsByShopperid(String shopperid, Integer limit, String category,
      String brand) {
    int defaultLimit = 10;
    int maxLimit = 100;
    int finalLimit = 0;
    if (limit != null) {
      finalLimit = limit == 0 ? defaultLimit : Math.min(limit, maxLimit);
    } else {
      finalLimit = defaultLimit;
    }

    Pageable pageable = PageRequest.of(0, finalLimit);
    return shopperRepository.findProductsByShopperid(shopperid, category, brand, pageable);
  }
}
