package com.civalue.personalized_data.repository;



@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = {PersonalizedDataServiceApplication.class})
@AutoConfigureMockMvc
public class ProductDaoTest {

  @Mock
  private ProductRepository productRepository;

  @InjectMocks
  private ProductDao productDao;

  @Test
  void test_insertProducts_normal() {
    List<ProductEntityDto> products = new ArrayList<>();
    when(productRepository.saveAll(products)).thenReturn(products);
    int result = productDao.insertProducts(products);
    assertEquals(products.size(), result);
    verify(productRepository, times(1)).saveAll(products);
  }

  @Test
  void test_getShoppersByProductid_normal() {
    String productId = "123";
    int limit = 10;
    List<String> shoppers = new ArrayList<>();
    Pageable pageable = PageRequest.of(0, limit);
    when(productRepository.findShoppersByProductid(productId, pageable)).thenReturn(shoppers);
    List<String> result = productDao.getShoppersByProductid(productId, limit);
    assertEquals(shoppers, result);
    verify(productRepository, times(1)).findShoppersByProductid(productId, pageable);
  }

  @Test
  void test_getShoppersByProductid_nullLimit() {
    String productId = "123";
    int limit = 10;
    List<String> shoppers = new ArrayList<>();
    Pageable pageable = PageRequest.of(0, limit);
    when(productRepository.findShoppersByProductid(productId, pageable)).thenReturn(shoppers);
    List<String> result = productDao.getShoppersByProductid(productId, null);
    assertEquals(shoppers, result);
    verify(productRepository, times(1)).findShoppersByProductid(productId, pageable);
  }
}

