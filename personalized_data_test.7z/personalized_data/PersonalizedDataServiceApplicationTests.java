package com.civalue.personalized_data;



@SpringBootTest
class PersonalizedDataServiceApplicationTests {

  @Test
  void contextLoads() {}

}
