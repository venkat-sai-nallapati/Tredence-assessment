package com.civalue.personalized_data.service;



@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = {PersonalizedDataServiceApplication.class})
@AutoConfigureMockMvc
public class ProductAndShopperServiceTest {


  @InjectMocks
  ProductAndShopperService productAndShopperService;

  @Mock
  ProductDao productDao;

  @Mock
  ShopperDao shopperDao;

  @Test
  void insertProductAndShopperData_normal() throws Exception {
    ObjectMapper mapper = new ObjectMapper();
    mapper.registerModule(new JavaTimeModule());
    DateFormat df = new SimpleDateFormat();
    mapper.setDateFormat(df);
    mapper.enable(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY);
    mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    File file = new File(
        "src/test/java/com/civalue/personalized_data/service/personalizedAndProductFile.json");
    PersonalizedAndProductRequestDto personalizedAndProductRequestDto =
        mapper.readValue(file, new TypeReference<PersonalizedAndProductRequestDto>() {});
    doReturn(2).when(productDao).insertProducts(Mockito.any());
    doReturn(3).when(shopperDao).insertShoppers(Mockito.any());
    productAndShopperService.insertProductAndShopperData(personalizedAndProductRequestDto);
  }

  @Test
  void insertProductAndShopperData_exception() throws Exception {
    ObjectMapper mapper = new ObjectMapper();
    mapper.registerModule(new JavaTimeModule());
    DateFormat df = new SimpleDateFormat();
    mapper.setDateFormat(df);
    mapper.enable(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY);
    mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    File file = new File(
        "src/test/java/com/civalue/personalized_data/service/personalizedAndProductFile.json");
    PersonalizedAndProductRequestDto personalizedAndProductRequestDto =
        mapper.readValue(file, new TypeReference<PersonalizedAndProductRequestDto>() {});
    doReturn(2).when(productDao).insertProducts(Mockito.any());
    doThrow(new RuntimeException()).when(shopperDao).insertShoppers(Mockito.any());
    assertThrows(RuntimeException.class, () -> {
      productAndShopperService.insertProductAndShopperData(personalizedAndProductRequestDto);
    });
  }
}
